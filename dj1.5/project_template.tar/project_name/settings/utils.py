
import os
LOCAL = lambda x: os.path.join(os.path.sep.join(
                os.path.abspath(
                    os.path.dirname(__file__)).split(os.path.sep)[:-1]), x)

