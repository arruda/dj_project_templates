===================================
{{ project_name }}
===================================

About this:
-----------------------------------

Some information


LICENSE
=============
This software is distributed using MIT license, see LICENSE file for more details.
