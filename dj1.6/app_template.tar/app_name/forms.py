#-*- coding:utf-8 -*-
"""
    {{ app_name }}.forms
    ~~~~~~~~~~~~~~

    {{ app_name }} forms file

    :copyright: (c) 2014 by arruda.
"""
from django import forms


