#-*- coding:utf-8 -*-
"""
    {{ app_name }}.admin
    ~~~~~~~~~~~~~~

    {{ app_name }} admin file
    
    :copyright: (c) 2012 by arruda.
"""
from django.contrib import admin




#admin.site.register(SomeModel, admin.ModelAdmin)
